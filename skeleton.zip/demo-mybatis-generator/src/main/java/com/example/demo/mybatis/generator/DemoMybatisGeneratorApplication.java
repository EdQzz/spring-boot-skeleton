package com.example.demo.mybatis.generator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMybatisGeneratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoMybatisGeneratorApplication.class, args);
    }

}
