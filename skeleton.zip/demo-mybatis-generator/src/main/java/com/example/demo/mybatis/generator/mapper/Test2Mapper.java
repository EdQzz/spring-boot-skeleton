package com.example.demo.mybatis.generator.mapper;

import com.example.demo.mybatis.generator.pojo.Test2;
import java.util.List;

public interface Test2Mapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Test2 record);

    Test2 selectByPrimaryKey(Integer id);

    List<Test2> selectAll();

    int updateByPrimaryKey(Test2 record);
}