package com.example.demo.mybatis.generator.mapper;

import com.example.demo.mybatis.generator.pojo.Test1;
import java.util.List;

public interface Test1Mapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Test1 record);

    Test1 selectByPrimaryKey(Integer id);

    List<Test1> selectAll();

    int updateByPrimaryKey(Test1 record);
}