package com.example.demo.common.utils;

public class TestUtils {
    public static String hello(){
        return "Hello World";
    }
}
