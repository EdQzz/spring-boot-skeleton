package com.example.demo.common;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoCommonApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoCommonApplication.class, args);
    }

}
