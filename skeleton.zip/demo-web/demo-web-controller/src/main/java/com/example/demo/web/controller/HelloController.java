package com.example.demo.web.controller;

import com.example.demo.common.utils.TestUtils;
import com.example.demo.web.service.HelloService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
    @Autowired
    private HelloService helloService;
    @RequestMapping("/hello")
    public String hello() {
        return  TestUtils.hello();
    }

    @RequestMapping("/hello-service")
    public String hello2() {
        return  helloService.hello();
    }

    @RequestMapping("/hello-jdbc")
    public String hello3() {
        return  helloService.testMapper();
    }
}
