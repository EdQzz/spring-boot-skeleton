package com.example.demo.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoWebPojoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoWebPojoApplication.class, args);
    }

}
