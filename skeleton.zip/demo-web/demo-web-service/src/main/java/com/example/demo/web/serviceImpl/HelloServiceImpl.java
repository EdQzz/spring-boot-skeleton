package com.example.demo.web.serviceImpl;

import com.example.demo.common.utils.TestUtils;
import com.example.demo.web.mapper.TestMapper;
import com.example.demo.web.service.HelloService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HelloServiceImpl implements HelloService {
    @Autowired
    private TestMapper testMapper;
    public String hello() {
        return "HelloService: "+TestUtils.hello();
    }
    public String testMapper() {
        return "HelloMapper: "+testMapper.selectByPrimaryKey(1);
    }
}
