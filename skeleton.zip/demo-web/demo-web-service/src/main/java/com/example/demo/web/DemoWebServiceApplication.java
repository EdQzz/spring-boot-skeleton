package com.example.demo.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoWebServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoWebServiceApplication.class, args);
    }

}
