package com.example.demo.web.service;

public interface HelloService {
    String hello();
    String testMapper();

}
