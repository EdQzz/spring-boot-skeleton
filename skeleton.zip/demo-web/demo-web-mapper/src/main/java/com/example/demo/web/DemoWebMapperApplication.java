package com.example.demo.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoWebMapperApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoWebMapperApplication.class, args);
    }

}
